package com.bikewheel.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private val FRONT_IP = "192.168.4.1"   // Front wheel XIAO AP IP
    private val REAR_IP  = "192.168.4.2"   // Rear wheel XIAO (if on same network)

    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    private lateinit var tvStatus: TextView
    private lateinit var tvRpm: TextView
    private lateinit var tvConnected: TextView
    private lateinit var btnOn: Button
    private lateinit var btnOff: Button
    private lateinit var btnNext: Button
    private lateinit var seekBrightness: SeekBar
    private lateinit var tvBrightness: TextView
    private lateinit var progressBar: ProgressBar

    private val handler = Handler(Looper.getMainLooper())
    private var pollRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus     = findViewById(R.id.tv_status)
        tvRpm        = findViewById(R.id.tv_rpm)
        tvConnected  = findViewById(R.id.tv_connected)
        btnOn        = findViewById(R.id.btn_on)
        btnOff       = findViewById(R.id.btn_off)
        btnNext      = findViewById(R.id.btn_next)
        seekBrightness = findViewById(R.id.seek_brightness)
        tvBrightness = findViewById(R.id.tv_brightness)
        progressBar  = findViewById(R.id.progress_bar)

        seekBrightness.max = 30
        seekBrightness.progress = 7  // Default brightness 8 (0-indexed = 7)

        seekBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                val val_ = progress + 1
                tvBrightness.text = "Brightness: $val_"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                send("/brightness/${sb.progress + 1}")
            }
        })

        btnOn.setOnClickListener   { send("/on") }
        btnOff.setOnClickListener  { send("/off") }
        btnNext.setOnClickListener { send("/next") }

        startPolling()
    }

    private fun send(path: String) {
        lifecycleScope.launch {
            showLoading(true)
            val result = withContext(Dispatchers.IO) {
                try {
                    val req = Request.Builder().url("http://$FRONT_IP$path").build()
                    val res = client.newCall(req).execute()
                    res.isSuccessful
                } catch (e: Exception) { false }
            }
            showLoading(false)
            if (!result) toast("Connection failed")
        }
    }

    private fun startPolling() {
        pollRunnable = object : Runnable {
            override fun run() {
                fetchStatus()
                handler.postDelayed(this, 3000)
            }
        }
        handler.post(pollRunnable!!)
    }

    private fun fetchStatus() {
        lifecycleScope.launch {
            val json = withContext(Dispatchers.IO) {
                try {
                    val req = Request.Builder().url("http://$FRONT_IP/status").build()
                    val res = client.newCall(req).execute()
                    res.body?.string()
                } catch (e: Exception) { null }
            }

            if (json != null) {
                try {
                    val obj = JSONObject(json)
                    val ledsOn     = obj.optBoolean("leds_on", false)
                    val rpm        = obj.optDouble("rpm", 0.0)
                    val spinning   = obj.optBoolean("is_spinning", false)
                    val brightness = obj.optInt("brightness", 8)
                    val frame      = obj.optInt("frame", 0)

                    tvConnected.text = "● Connected"
                    tvConnected.setTextColor(getColor(R.color.green))
                    tvStatus.text = if (ledsOn) "LEDs ON" else "LEDs OFF"
                    tvRpm.text = "%.0f RPM".format(rpm)
                    seekBrightness.progress = brightness - 1
                    tvBrightness.text = "Brightness: $brightness"

                } catch (e: Exception) {
                    setDisconnected()
                }
            } else {
                setDisconnected()
            }
        }
    }

    private fun setDisconnected() {
        tvConnected.text = "○ Disconnected"
        tvConnected.setTextColor(getColor(R.color.red))
        tvStatus.text = "—"
        tvRpm.text = "— RPM"
    }

    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        pollRunnable?.let { handler.removeCallbacks(it) }
    }
}
